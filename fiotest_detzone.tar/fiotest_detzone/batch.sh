#!/bin/bash

for i in {0..128..2}
	
do
	/home/jaehongm/fio/fio --time_based --runtime=3000 --section=read4_proportional --section=write1_1z  rw_fairness.fio --numjobs=3 --offset=${i}g --output=tmp.log
	cat tmp.log >> rw_prop.log
done

