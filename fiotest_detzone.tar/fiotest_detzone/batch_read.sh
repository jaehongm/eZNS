
/home/jaehongm/fio/fio --section=read1 --section=read2 --minimal --output=tmp.log read.fio
cat tmp.log >> output.log

/home/jaehongm/fio/fio --section=read1 --section=read2 --minimal --output=tmp.log read.fio
cat tmp.log >> output.log

/home/jaehongm/fio/fio --section=read1 --section=read3 --minimal --output=tmp.log read.fio
cat tmp.log >> output.log

/home/jaehongm/fio/fio --section=read1 --section=read4 --minimal --output=tmp.log read.fio
cat tmp.log >> output.log

/home/jaehongm/fio/fio --section=read1 --section=read5 --minimal --output=tmp.log read.fio
cat tmp.log >> output.log

/home/jaehongm/fio/fio --section=read2 --section=read3 --minimal --output=tmp.log read.fio
cat tmp.log >> output.log

/home/jaehongm/fio/fio --section=read2 --section=read4 --minimal --output=tmp.log read.fio
cat tmp.log >> output.log

/home/jaehongm/fio/fio --section=read2 --section=read5 --minimal --output=tmp.log read.fio
cat tmp.log >> output.log

/home/jaehongm/fio/fio --section=read3 --section=read4 --minimal --output=tmp.log read.fio
cat tmp.log >> output.log

/home/jaehongm/fio/fio --section=read3 --section=read5 --minimal --output=tmp.log read.fio
cat tmp.log >> output.log

/home/jaehongm/fio/fio --section=read1 --section=read2 --section=read3 --minimal --output=tmp.log read.fio
cat tmp.log >> output.log

