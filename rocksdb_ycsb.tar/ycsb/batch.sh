#!/bin/bash

NUM_KEYS=50000000
OP_NUM=2000000
COMMON_OPTS="--disable_seek_compaction=1 \
	--mmap_read=0 \
	--statistics=1 \
	--histogram=1 \
	--key_size=16 \
	--value_size=1024 \
	--block_size=4096 \
	--bloom_bits=10 \
	--cache_numshardbits=4 \
	--open_files=500 \
	--sync=0 \
	--compression_type=none \
	--stats_interval=6000000 \
	--compression_ratio=1 \
	--target_file_size_multiplier=2 \
	--write_buffer_size=67108864 \
	--max_write_buffer_number=6 \
	--min_write_buffer_number_to_merge=2 \
	--num_levels=10 \
	--stats_per_interval=1 \
	--max_bytes_for_level_base=671088640 \
	--level0_slowdown_writes_trigger=20 \
	--level0_stop_writes_trigger=24 \
	--threads=6 \
	--disable_wal=1 \
	--num=$NUM_KEYS \
	--cache_size=4096000000 \
	--hotspot_num=1 \
	--max_background_jobs=8 \
	--max_bytes_for_level_multiplier=4 \
	--skewness=0.9 \
	--level0_file_num_compaction_trigger=8 \
	--use_direct_io_for_flush_and_compaction=1 \
	--use_direct_reads"

#echo deadline > /sys/class/block/nvme1n1/queue/scheduler
#echo deadline > /sys/class/block/nvme1n2/queue/scheduler
#echo deadline > /sys/class/block/nvme1n3/queue/scheduler
#echo deadline > /sys/class/block/nvme1n4/queue/scheduler

#./zenfs_device_setup.sh nvme1n1
#./zenfs_device_setup.sh nvme1n2
#./zenfs_device_setup.sh nvme1n3
#./zenfs_device_setup.sh nvme1n4

DEV="nvme1n1"
CAP_SECTORS=$(nvme zns report -d 5 /dev/$DEV | grep -oP '(?<=Cap: )[0-9xa-f]+' | head -1)
ZONE_CAP=$(($CAP_SECTORS * 4096))
ZONE_MOR=$(($(nvme zns id-ns /dev/$DEV | grep mor | grep -oE '[0-9xa-f]+') + 1))
ZENFS_OPTS="--target_file_size_base=$(($ZONE_CAP * 2 * 95 / 100))"

../db_bench $COMMON_OPTS $ZENFS_OPTS --use_existing_db=0 --benchmarks=fillseq,compact --fs_uri=zenfs://dev:nvme1n1 &
../db_bench $COMMON_OPTS $ZENFS_OPTS --use_existing_db=0 --benchmarks=fillseq,compact --fs_uri=zenfs://dev:nvme1n2 &
../db_bench $COMMON_OPTS $ZENFS_OPTS --use_existing_db=0 --benchmarks=fillseq,compact --fs_uri=zenfs://dev:nvme1n3 &
../db_bench $COMMON_OPTS $ZENFS_OPTS --use_existing_db=0 --benchmarks=fillseq,compact --fs_uri=zenfs://dev:nvme1n4 &
#../db_bench $COMMON_OPTS --use_existing_db=0 --benchmarks=fillseq,compact --db=/mnt/btrfs/ &
#../db_bench $COMMON_OPTS --use_existing_db=0 --benchmarks=fillseq,compact --db=/mnt/data/jaehongm/f2fsn1/ &
#../db_bench $COMMON_OPTS --use_existing_db=0 --benchmarks=fillseq,compact --db=/mnt/data/jaehongm/f2fsn2/ &
#../db_bench $COMMON_OPTS --use_existing_db=0 --benchmarks=fillseq,compact --db=/mnt/data/jaehongm/f2fsn3/ &
#../db_bench $COMMON_OPTS --use_existing_db=0 --benchmarks=fillseq,compact --db=/mnt/data/jaehongm/f2fsn4/ &
wait

../db_bench $COMMON_OPTS $ZENFS_OPTS --use_existing_db=1 --op_num=$OP_NUM --benchmarks=ycsbwklda[-X2] --fs_uri=zenfs://dev:nvme1n1 2>&1 | tee -a n1-ycsb.log &
../db_bench $COMMON_OPTS $ZENFS_OPTS --use_existing_db=1 --op_num=$OP_NUM --benchmarks=ycsbwkldb[-X2] --fs_uri=zenfs://dev:nvme1n2 2>&1 | tee -a n2-ycsb.log &
../db_bench $COMMON_OPTS $ZENFS_OPTS --use_existing_db=1 --op_num=$OP_NUM --benchmarks=ycsbwkldc[-X2] --fs_uri=zenfs://dev:nvme1n3 2>&1 | tee -a n3-ycsb.log &
../db_bench $COMMON_OPTS $ZENFS_OPTS --use_existing_db=1 --op_num=$OP_NUM --benchmarks=ycsbwkldf[-X2] --fs_uri=zenfs://dev:nvme1n4 2>&1 | tee -a n4-ycsb.log &
#../db_bench $COMMON_OPTS --use_existing_db=1 --op_num=$OP_NUM --benchmarks=ycsbwklda[-X2] --db=/mnt/btrfs/ 2>&1 | tee -a n1-ycsb.log &
#../db_bench $COMMON_OPTS --use_existing_db=1 --op_num=$OP_NUM --benchmarks=ycsbwklda[-X2] --db=/mnt/data/jaehongm/f2fsn1/ 2>&1 | tee -a n1-ycsb.log &
#../db_bench $COMMON_OPTS --use_existing_db=1 --op_num=$OP_NUM --benchmarks=ycsbwkldb[-X2] --db=/mnt/data/jaehongm/f2fsn2/ 2>&1 | tee -a n2-ycsb.log &
#../db_bench $COMMON_OPTS --use_existing_db=1 --op_num=$OP_NUM --benchmarks=ycsbwkldc[-X2] --db=/mnt/data/jaehongm/f2fsn3/ 2>&1 | tee -a n3-ycsb.log &
#../db_bench $COMMON_OPTS --use_existing_db=1 --op_num=$OP_NUM --benchmarks=ycsbwkldf[-X2] --db=/mnt/data/jaehongm/f2fsn4/ 2>&1 | tee -a n4-ycsb.log &
wait


