#!/bin/bash

./zenfs_device_setup.sh nvme1n1
./zenfs_device_setup.sh nvme1n2
./zenfs_device_setup.sh nvme1n3
./zenfs_device_setup.sh nvme1n4

