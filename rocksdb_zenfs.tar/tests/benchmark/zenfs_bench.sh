#!/bin/bash
set -e

# Example:
#   sudo ./zenfs_base_performance.sh nvme2n1 nvme2c1n1 [ /mnt ]

DEV=$1
MNT=$2

if [[ "$MNT" == "" ]]; then
    echo deadline > /sys/class/block/$DEV/queue/scheduler
    MKFS_ARG="--zbd="$DEV
    FS_URI="zenfs://dev:$DEV"
else
    MKFS_ARG="--zonefs="$MNT
    FS_URI="zenfs://zonefs:$MNT"
fi

AUXPATH=$DEV-aux

sudo rm -rf /tmp/$AUXPATH && sudo ../../util/zenfs mkfs $MKFS_ARG --aux_path=/tmp/$AUXPATH --finish_threshold=10 --force

echo "Using URI "$FS_URI

