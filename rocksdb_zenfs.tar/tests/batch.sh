
#../../../db_bench --benchmarks=fillrandom --disable_wal=1 --num=$NUM_KEYS --value_size=800 --compression_type=none --histogram --db=/mnt/test_drv/db --wal_dir=/mnt/test_drv/wal --target_file_size_base=1529833062 --use_direct_io_for_flush_and_compaction --max_bytes_for_level_multiplier=4 --max_background_jobs=4 --use_direct_reads --write_buffer_size=2147483648 --statistics=0 --stats_per_interval=1 --stats_interval_seconds=60 --histogram=1 2>&1 | tee -a $DEV-$LOGNAME

#LOGNAME=batch-results-`date +%Y%m%d-%H:%M`.log
LOGNAME=batch-results-temp.log
#RNDSEED=`date +%s`
RNDSEED=1670225946
COMMON_BENCH_OPTS="
	--key_size=20 \
	--value_size=400 \
	--cache_size=6442450944 \
	--cache_numshardbits=6 \
	--compression_type=none \
	--use_direct_reads \
	--use_direct_io_for_flush_and_compaction \
	--statistics=0 \
	--stats_per_interval=1 \
	--stats_interval_seconds=180 \
	--histogram=1 \
	--seed=$RNDSEED"

DIO_OPTS="
"
#"--max_bytes_for_level_multiplier=4"

WB_SIZE=2147483648
WB_OPTS="--write_buffer_size=$WB_SIZE"
#WB_OPTS="--write_buffer_size=268435456 --max_write_buffer_number=8"

WAL_OPTS="--disable_wal=1"
NUM_KEYS=500000000
DURATION=600

#CMD="../../../db_bench $COMMON_BENCH_OPTS $WAL_OPTS $WB_OPTS $DEV_SPECI_OPTS --benchmarks=fillrandom,stats --disable_auto_compactions=1 --sync=0 --threads=1 --memtablerep=vector --allow_concurrent_memtable_write=false --num=$NUM_KEYS --db=/mnt/test_drv/db --wal_dir=/mnt/test_drv/wal 2>&1 | tee -a $DEV-$LOGNAME"
#CMD="../../../db_bench $COMMON_BENCH_OPTS $WAL_OPTS $WB_OPTS $DEV_SPECI_OPTS --benchmarks=compact,stats --use_existing_db=1 --disable_auto_compactions=1 --sync=0 --threads=1 --fs_uri=zenfs://dev:$DEV --compaction_style=0 --num_levels=8 --level_compaction_dynamic_level_bytes=true --pin_l0_filter_and_index_blocks_in_cache=1 2>&1 | tee -a $DEV-$LOGNAME"
#CMD="../../../db_bench $COMMON_BENCH_OPTS $WAL_OPTS $WB_OPTS $DEV_SPECI_OPTS --benchmarks=compact,stats --use_existing_db=1 --disable_auto_compactions=1 --sync=0 --threads=1 --db=/mnt/test_drv/db --wal_dir=/mnt/test_drv/wal --compaction_style=0 --num_levels=8 --level_compaction_dynamic_level_bytes=true --pin_l0_filter_and_index_blocks_in_cache=1 2>&1 | tee -a $DEV-$LOGNAME"


#--min_write_buffer_number_to_merge=$(($ZONE_CAP / 268435456 / 2 + 1 )) \
#--level0_file_num_compaction_trigger=2 \

function fillseq() {
	DEV=$1
	DB_URI=$2
	CAP_SECTORS=$(nvme zns report -d 5 /dev/$DEV | grep -oP '(?<=Cap: )[0-9xa-f]+' | head -1)
	ZONE_CAP=$(($CAP_SECTORS * 4096))
	ZONE_MOR=$(($(nvme zns id-ns /dev/$DEV | grep mor | grep -oE '[0-9xa-f]+') + 1))
	BG_JOBS=${3:-$ZONE_MOR}
	DEV_SPECI_OPTS="
		--target_file_size_base=$(($ZONE_CAP * 2 * 95 / 100)) \
		--max_background_jobs=$BG_JOBS"

	CMD="../../../db_bench $COMMON_BENCH_OPTS $WAL_OPTS $WB_OPTS $DEV_SPECI_OPTS $DB_URI --benchmarks=fillseq,stats --disable_auto_compactions=1 --sync=0 --threads=1 --memtablerep=vector --allow_concurrent_memtable_write=false --num=$NUM_KEYS 2>&1 | tee -a $DEV-$LOGNAME"
	echo $CMD
	echo $CMD >> $LOGNAME
	eval $CMD
	CMD="../../../db_bench $COMMON_BENCH_OPTS $WAL_OPTS $WB_OPTS $DEV_SPECI_OPTS $DB_URI --benchmarks=compact,stats --use_existing_db=1 --disable_auto_compactions=1 --sync=0 --threads=1 2>&1 | tee -a $DEV-$LOGNAME"
	echo $CMD
	echo $CMD >> $LOGNAME
	eval $CMD
}

function fillrandom() {
	DEV=$1
	DB_URI=$2
	CAP_SECTORS=$(nvme zns report -d 5 /dev/$DEV | grep -oP '(?<=Cap: )[0-9xa-f]+' | head -1)
	ZONE_CAP=$(($CAP_SECTORS * 4096))
	ZONE_MOR=$(($(nvme zns id-ns /dev/$DEV | grep mor | grep -oE '[0-9xa-f]+') + 1))
	BG_JOBS=${3:-$ZONE_MOR}
	DEV_SPECI_OPTS="
		--target_file_size_base=$(($ZONE_CAP * 2 * 95 / 100)) \
		--max_background_jobs=$BG_JOBS"

	CMD="../../../db_bench $COMMON_BENCH_OPTS $WAL_OPTS $WB_OPTS $DEV_SPECI_OPTS $DB_URI --benchmarks=fillrandom,stats --disable_auto_compactions=0 --sync=0 --threads=1 --memtablerep=vector --allow_concurrent_memtable_write=false --num=$NUM_KEYS 2>&1 | tee -a $DEV-$LOGNAME"
	echo $CMD
	echo $CMD >> $LOGNAME
	eval $CMD
#	CMD="../../../db_bench $COMMON_BENCH_OPTS $WAL_OPTS $WB_OPTS $DEV_SPECI_OPTS $DB_URI --benchmarks=compact,stats --use_existing_db=1 --sync=0 --threads=1 --memtablerep=vector --allow_concurrent_memtable_write=false --num=$NUM_KEYS 2>&1 | tee -a $DEV-$LOGNAME"
#	echo $CMD
#	eval $CMD
}

function readrandom() {
	DEV=$1
	DB_URI=$2
	THREADS=${3:-1}
	CAP_SECTORS=$(nvme zns report -d 5 /dev/$DEV | grep -oP '(?<=Cap: )[0-9xa-f]+' | head -1)
	ZONE_CAP=$(($CAP_SECTORS * 4096))
	ZONE_MOR=$(($(nvme zns id-ns /dev/$DEV | grep mor | grep -oE '[0-9xa-f]+') + 1))
	BG_JOBS=${4:-$ZONE_MOR}
	DEV_SPECI_OPTS="
		--target_file_size_base=$(($ZONE_CAP * 2 * 95 / 100)) \
		--max_background_jobs=$BG_JOBS"

	CMD="../../../db_bench --bloom_bits=10 --use_existing_db=1 --duration=$DURATION --threads=$THREADS $COMMON_BENCH_OPTS $WAL_OPTS $WB_OPTS $DEV_SPECI_OPTS $DB_URI --benchmarks=readrandom,stats --disable_auto_compactions=1 --num=$NUM_KEYS 2>&1 | tee -a $DEV-$LOGNAME"
	echo $CMD
	echo $CMD >> $LOGNAME
	eval $CMD
}

function overwrite() {
	DEV=$1
	DB_URI=$2
	THREADS=${3:-1}
	WRITE_RATE=$((${4:-0} * 1024 * 1024))
	CAP_SECTORS=$(nvme zns report -d 5 /dev/$DEV | grep -oP '(?<=Cap: )[0-9xa-f]+' | head -1)
	ZONE_CAP=$(($CAP_SECTORS * 4096))
	ZONE_MOR=$(($(nvme zns id-ns /dev/$DEV | grep mor | grep -oE '[0-9xa-f]+') + 1))
	BG_JOBS=${5:-$ZONE_MOR}
	DEV_SPECI_OPTS="
		--target_file_size_base=$(($ZONE_CAP * 2 * 95 / 100)) \
		--max_background_jobs=$BG_JOBS"

		CMD="../../../db_bench --bloom_bits=10 --use_existing_db=1 --duration=$DURATION --threads=$THREADS --benchmark_write_rate_limit=$WRITE_RATE $COMMON_BENCH_OPTS $WAL_OPTS $WB_OPTS $DEV_SPECI_OPTS $DB_URI --benchmarks=overwrite,stats --disable_auto_compactions=0 2>&1 | tee -a $DEV-$LOGNAME"
	echo $CMD
	echo $CMD >> $LOGNAME
	eval $CMD
}

function readwhilewriting() {
	DEV=$1
	DB_URI=$2
	THREADS=${3:-1}
	WRITE_RATE=$((${4:-0} * 1024 * 1024))
	CAP_SECTORS=$(nvme zns report -d 5 /dev/$DEV | grep -oP '(?<=Cap: )[0-9xa-f]+' | head -1)
	ZONE_CAP=$(($CAP_SECTORS * 4096))
	ZONE_MOR=$(($(nvme zns id-ns /dev/$DEV | grep mor | grep -oE '[0-9xa-f]+') + 1))
	BG_JOBS=${5:-$ZONE_MOR}
	DEV_SPECI_OPTS="
		--target_file_size_base=$(($ZONE_CAP * 2 * 95 / 100)) \
		--max_background_jobs=$BG_JOBS"

	CMD="../../../db_bench --bloom_bits=10 --use_existing_db=1 --duration=$DURATION --threads=$THREADS --benchmark_write_rate_limit=$WRITE_RATE $COMMON_BENCH_OPTS $WAL_OPTS $WB_OPTS $DEV_SPECI_OPTS $DB_URI --benchmarks=readwhilewriting,stats --disable_auto_compactions=0 --num=$NUM_KEYS 2>&1 | tee -a $DEV-$LOGNAME"
	echo $CMD
	echo $CMD >> $LOGNAME
	eval $CMD
}

function run_batch_zns_single() {
	if [ -z "$1" ]; then 
		echo "need arguments"
		return
	fi

	./zenfs_device_setup.sh $1
	fillrandom $1 "--fs_uri=zenfs://dev:$1" 8

#	readrandom $1 "--fs_uri=zenfs://dev:$1" 1
#	readrandom $1 "--fs_uri=zenfs://dev:$1" 64


	overwrite $1 "--fs_uri=zenfs://dev:$1" 1
	readwhilewriting $1 "--fs_uri=zenfs://dev:$1" 16 20
#	readwhilewriting $1 "--fs_uri=zenfs://dev:$1" 16 0 1
#	readwhilewriting $1 "--fs_uri=zenfs://dev:$1" 16 0 2
#	readwhilewriting $1 "--fs_uri=zenfs://dev:$1" 16 0 4
#	readwhilewriting $1 "--fs_uri=zenfs://dev:$1" 16 0 6
#	readwhilewriting $1 "--fs_uri=zenfs://dev:$1" 16  
}

function run_batch_zns_double() {
	if [ -z "$1" ]; then 
		echo "need arguments"
		return
	fi
	if [ -z "$2" ]; then 
		echo "need arguments"
		return
	fi
	
	WR_BW=${3:-20}
	READ_JOBS=${4:-64}

	overwrite $1 "--fs_uri=zenfs://dev:$1" 1 $WR_BW &
	readrandom $2 "--fs_uri=zenfs://dev:$2" $READ_JOBS &
	wait
}

function run_batch_zns_4() {
	
	./zenfs_device_setup.sh $1
	./zenfs_device_setup.sh $2
	./zenfs_device_setup.sh $3
	./zenfs_device_setup.sh $4

	fillseq $1 "--fs_uri=zenfs://dev:$1" 8 &
	fillseq $2 "--fs_uri=zenfs://dev:$2" 8 &
	fillseq $3 "--fs_uri=zenfs://dev:$3" 8 &
	fillseq $4 "--fs_uri=zenfs://dev:$4" 8 &
	wait

	overwrite $1 "--fs_uri=zenfs://dev:$1" 1 &
	overwrite $2 "--fs_uri=zenfs://dev:$2" 1 &
	overwrite $3 "--fs_uri=zenfs://dev:$3" 1 &
	overwrite $4 "--fs_uri=zenfs://dev:$4" 1 &
	wait
	
	overwrite $1 "--fs_uri=zenfs://dev:$1" 1 &
	overwrite $2 "--fs_uri=zenfs://dev:$2" 1 &
	readrandom $3 "--fs_uri=zenfs://dev:$3" 32 8 &
	readrandom $4 "--fs_uri=zenfs://dev:$4" 32 8 &
	wait
}

function run_batch_zns_4_read() {
	overwrite $1 "--fs_uri=zenfs://dev:$1" 8 &
	overwrite $2 "--fs_uri=zenfs://dev:$2" 8 &
	readrandom $3 "--fs_uri=zenfs://dev:$3" 64 8 &
	readrandom $4 "--fs_uri=zenfs://dev:$4" 64 8 &
	wait
}

run_batch_zns_4 nvme1n1 nvme1n2 nvme1n3 nvme1n4
#run_batch_zns_4_read nvme1n1 nvme1n2 nvme1n3 nvme1n4

#./zenfs_device_setup.sh nvme1n2
#fillrandom nvme1n2 "--fs_uri=zenfs://dev:nvme1n2"
#readrandom nvme1n2 "--fs_uri=zenfs://dev:nvme1n2" 64
#overwrite nvme1n2 "--fs_uri=zenfs://dev:nvme1n2" 1
#readwhilewriting nvme1n2 "--fs_uri=zenfs://dev:nvme1n2" 16 
#run_batch_zns_single nvme1n1
#run_batch_zns_single nvme1n3
#run_batch_zns_single nvme1n4

#readrandom nvme1n1 "--fs_uri=zenfs://dev:nvme1n1" 64
#readrandom nvme1n2 "--fs_uri=zenfs://dev:nvme1n2" 64
#readrandom nvme1n3 "--fs_uri=zenfs://dev:nvme1n3" 64
#readrandom nvme1n4 "--fs_uri=zenfs://dev:nvme1n4" 64

exit 1

BTRFS_DEV=nvme1n3
umount /mnt/test_drv
mkfs.btrfs -m single -d single -f /dev/$BTRFS_DEV
mount /dev/$BTRFS_DEV /mnt/test_drv
#fillseq $BTRFS_DEV "--db=/mnt/test_drv/db --wal_dir=/mnt/test_drv/wal"
fillrandom $BTRFS_DEV "--db=/mnt/test_drv/db --wal_dir=/mnt/test_drv/wal"
overwrite $BTRFS_DEV "--db=/mnt/test_drv/db --wal_dir=/mnt/test_drv/wal" 1
readwhilewriting $BTRFS_DEV "--db=/mnt/test_drv/db --wal_dir=/mnt/test_drv/wal" 16 20
readwhilewriting $BTRFS_DEV "--db=/mnt/test_drv/db --wal_dir=/mnt/test_drv/wal" 16 0 1
readwhilewriting $BTRFS_DEV "--db=/mnt/test_drv/db --wal_dir=/mnt/test_drv/wal" 16 0 2
readwhilewriting $BTRFS_DEV "--db=/mnt/test_drv/db --wal_dir=/mnt/test_drv/wal" 16 0 4
readwhilewriting $BTRFS_DEV "--db=/mnt/test_drv/db --wal_dir=/mnt/test_drv/wal" 16 0 6
readwhilewriting $BTRFS_DEV "--db=/mnt/test_drv/db --wal_dir=/mnt/test_drv/wal" 16 



