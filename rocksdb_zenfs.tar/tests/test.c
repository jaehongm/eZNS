typedef unsigned long uint64_t;

struct test {
	uint64_t nr_zones;
	char reserved8[56];
	int descs[];
}

ppp(void *p)
{
	int i = 0;
	while(i < 16) {
		printf("%x\n",(char)((char*)p)[60+i]);
		i++;
	}
}

main()
{
	void *p = calloc(1, 80);
	struct test *t = p;
	*(void**)t->descs = 0xf0f0f0f0f0f0f0f0;
	ppp(p);
	
}

