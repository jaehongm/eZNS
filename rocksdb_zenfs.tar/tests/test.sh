
THREAD=$1

THREAD=${1:-1}

echo $THREAD

